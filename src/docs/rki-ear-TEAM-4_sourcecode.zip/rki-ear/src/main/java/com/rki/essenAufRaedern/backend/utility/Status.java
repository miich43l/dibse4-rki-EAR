package com.rki.essenAufRaedern.backend.utility;

/**
 * @Value status to set records active or inactive
 */
public enum Status {
    ACTIVE, INACTIVE
}
